# projeto-arvoreBinariaPesquisa
 Mini projeto da matéria de Estrutura de Dados I do professor Walace Bonfim
